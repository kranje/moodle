<?php
/**
 * Language entries for NSSE Survey
 *
 * 
 **/

$string['blockname'] = 'NSSE Survey';
$string['pluginname'] = 'NSSE Survey';
