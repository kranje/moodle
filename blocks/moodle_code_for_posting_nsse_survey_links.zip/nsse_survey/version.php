<?php
/**
 * Version control for NSSE Survey
 *
 * 
 **/
 
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2015111600;        // The current plugin version (Date: YYYYMMDDXX)
$plugin->requires  = 2015111600;        // Requires this Moodle version
$plugin->component = 'block_nsse_survey'; // Full name of the plugin (used for diagnostics)
